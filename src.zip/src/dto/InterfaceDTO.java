package dto;

public interface InterfaceDTO {
    
}
